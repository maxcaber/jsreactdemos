export function getCube(x:number):number{
    return x*x*x;
}